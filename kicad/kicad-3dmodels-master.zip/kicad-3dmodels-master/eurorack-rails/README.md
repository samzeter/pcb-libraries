# kicad-3dmodels

FISCHER BGT GB 29L:

![FISCHER BGT GB 29L](https://github.com/dhaillant/kicad-3dmodels/raw/master/eurorack-rails/FISCHER%20BGT%20GB%2029L.png)


