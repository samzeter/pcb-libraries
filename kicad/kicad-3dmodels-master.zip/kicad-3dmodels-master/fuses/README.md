# kicad-3dmodels

PTF/78 5x20 Fuse Holder from https://www.stelvio-kontek.com/:
![PTF/78](https://github.com/dhaillant/kicad-3dmodels/raw/master/fuses/FUSE-HOLDER-PTF78.png)
